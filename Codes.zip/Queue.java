public class Queue {

	//Attributes
	int[] queue;
	int size;

	//Constructors
	public Queue(){
		queue = new int[0];
		size = queue.length;
	}
	public Queue(int[] elements){
		queue = elements;
		size = queue.length;
	}

	//Methods
	public void display(){
		for(int i=size; i>0; i--)
			System.out.print(queue[i-1]+" ");
		System.out.println();
	}
	//Method isEmpty()
	//Method size()
	//Method first()
	//Method enqueue(int e)
	//Method dequeue()
}
