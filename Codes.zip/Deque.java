public class Deque {

	//Attributes
	int[] queue;
	int size;

	//Constructors
	public Deque(){
		queue = new int[0];
		size = queue.length;
	}
	public Deque(int[] elements){
		queue = elements;
		size = queue.length;
	}

	//Methods
	public void display(){
		for(int i=size; i>0; i--)
			System.out.print(queue[i-1]+" ");
		System.out.println();
	}
	//Method isEmpty()
	//Method size()
	//Method first()
	//Method last()
	//Method addLast(int e)
	//Method addFirst(int e)
	//Method removeFirst()
	//Method removeLast()
}
