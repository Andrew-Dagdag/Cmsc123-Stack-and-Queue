class StackTest {
	public static void main(String[] args){
		Stack s = new Stack(new int[]{37,50});
		s.display();
	}
}
