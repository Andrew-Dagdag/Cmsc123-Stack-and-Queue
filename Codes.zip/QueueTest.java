class QueueTest {
	public static void main(String[] args){
		MyQueue q = new MyQueue(new int[]{37,50});
		q.display();
		System.out.println(q.size());
	}
}
